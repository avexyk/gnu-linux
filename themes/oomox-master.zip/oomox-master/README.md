oomox
=====

### numix fork with color changing script


##### usage:
```sh
git clone https://github.com/actionless/oomox.git
cd oomox
ls colors
./change_color.sh gnome_noble  # or other theme from above
```
next select oomox_current in your appearance config tool (for example, _lxappearance_)

also u can generate the theme in web UI: http://actionless.github.io/oomox/

![Screenshot](http://fc09.deviantart.net/fs71/f/2014/145/7/9/oomox___change_numix_colorscheme_by_actionless-d7jo5ul.png "Screenshot")

![Web UI](http://i.imgur.com/PeZXH4Z.png "Web UI")
