hexchars="0123456789ABCDEF"
random_color () {
  echo $( for i in {1..6} ; do echo -n ${hexchars:$(( $RANDOM % 16 )):1} ; done )
}

   NAME="random theme"
     BG=$(random_color)
     FG=$(random_color)
 SEL_BG=$(random_color)
 SEL_FG=$(random_color)
 TXT_BG=$(random_color)
 TXT_FG=$(random_color)
MENU_BG=$(random_color)
MENU_FG=$(random_color)
 BTN_BG=$(random_color)
 BTN_FG=$(random_color)
